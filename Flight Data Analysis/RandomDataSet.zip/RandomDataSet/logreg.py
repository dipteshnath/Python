# -*- coding: utf-8 -*-
"""
Created on Fri Dec  9 22:00:31 2016

@author: Vinayak
"""

import pandas as pd
from sklearn import linear_model
from sklearn.metrics import confusion_matrix, precision_recall_fscore_support, accuracy_score,f1_score

x_train = pd.read_csv('finalAtlNyc.csv', header = 0)
x_test = pd.read_csv('finalAtlNyctest.csv', header = 0)

y_train = pd.read_csv('y_train.csv', header=0)
y_test = pd.read_csv('y_test.csv', header=0)


clf_lr = linear_model.LogisticRegression(penalty='l2', class_weight='auto')
clf_lr.fit(x_train.as_matrix(), y_train.as_matrix())

pr = clf_lr.predict(x_test.as_matrix())

cm = confusion_matrix(y_test.as_matrix(), pr)
print("Confusion matrix")

print(pd.DataFrame(cm))

report_lr = precision_recall_fscore_support(list(y_test.as_matrix()), list(pr), average='micro')
#print(metrics.f1_score(newsgroups_test.target, pred, average='weighted'))
print ("\nprecision = %0.2f, recall = %0.2f, F1 = %0.2f, accuracy = %0.2f\n" % \
       (report_lr[0], report_lr[1], report_lr[2], accuracy_score(list(y_test.as_matrix()), list(pr))))
