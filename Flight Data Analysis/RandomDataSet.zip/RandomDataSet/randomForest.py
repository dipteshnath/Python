# -*- coding: utf-8 -*-
"""
Created on Sat Dec  3 21:58:57 2016

@author: Vinayak
"""

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, precision_recall_fscore_support, accuracy_score,f1_score

x_train = pd.read_csv('finalAtlNyc.csv', header = 0)
x_test = pd.read_csv('finalAtlNyctest.csv', header = 0)

y_train = pd.read_csv('y_train.csv', header=0)
y_test = pd.read_csv('y_test.csv', header=0)

clf_rf = RandomForestClassifier(n_estimators=50, n_jobs=-1)
clf_rf.fit(x_train.as_matrix(), y_train.as_matrix())

pr_rf = clf_rf.predict(x_test.as_matrix())

cm = confusion_matrix(y_test.as_matrix(), pr_rf)
print("Confusion matrix")
print(pd.DataFrame(cm))
report_svm = precision_recall_fscore_support(list(y_test.as_matrix()), list(pr_rf), average='micro')
print ("\nprecision = %0.2f, recall = %0.2f, F1 = %0.2f, accuracy = %0.2f\n" % \
      (report_svm[0], report_svm[1], report_svm[2], accuracy_score(list(y_test.as_matrix()), list(pr_rf))))
        